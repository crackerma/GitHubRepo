<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");

	$mid = $_GET["mid"]; //mid for Manufacturer ID
	$f = $_GET["f"]; //f for Facebook ID
	$review = $_GET["review"]; //review for reviews
	$rate = $_GET["rate"]; //rate for ratings
	  
	// Store manufacturer review into database
        
        if ($mid != '' && $f != '' && $review != '' && $rate != '') {
        
                $query = "INSERT INTO manufacturerreview (ManufacturerID, FacebookID, Review, Rating)
                                        Value('".$mid."', '".$f."', '".$review."', '".$rate."')";
                $result = mysql_query($query);
                
                if ($result) {
                        echo "Success";
                }
        }
        
	$db->disconnect();
	
?>