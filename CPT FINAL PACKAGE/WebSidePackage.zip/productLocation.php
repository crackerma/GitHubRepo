<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");

	$r = $_GET["p"]; //p for product barcode
	
	// Create an empty array for later use
        
	$req = array( 
		"info" => '',  
		"data" => '' 
	);
	
	// Retrieve product location information, only store product name this time
        
	$query = "SELECT product.Name AS P_Name, location.Name, location.Description, location.Image, 
			location.Latitude, location.Longitude, location.NextLocationID  FROM location, product
			WHERE product.ProductID='".$r."' AND location.ProductID='".$r."'";
	$result = mysql_query($query);
	if (mysql_num_rows($result) <= 0) {
		$req['info'] = 0; // Product Not Exist
	}
	
	if($result){
		while($row = mysql_fetch_array($result)){
                  	// Put product name into the array
			$p = array(
				"ProductName" => $row['P_Name'],
				"Locations" => ''
			);
		}
	}
	
	$i = array(); // Temp array to store location information
        
	// Retrieve product location information, store product location information this time
	
	$query = "SELECT product.Name AS P_Name, location.Name, location.Description, location.Image, 
			location.Latitude, location.Longitude, location.NextLocationID  FROM location, product
			WHERE product.ProductID='".$r."' AND location.ProductID='".$r."'";
	$result = mysql_query($query);
	
	getLocations($result, $req, $i);
        
	// getLocation function: put sequential product location information into one array
        
        function getLocations ($result, &$req, &$i) {		
		if($result){
			while($row = mysql_fetch_array($result)){
				$req["info"] = 1; // Product Exists
                          	
                                // First location in the series
                                
				$list = array(
					"LocationName" => $row['Name'],
					"Description" => $row['Description'],
					"Image" => $row['Image'], 
					"Latitude" => $row['Latitude'], 
					"Longitdue" => $row['Longitude']
				);				
				
                          	array_push($i, $list); // Push information into the temp array
				
				
				if ($row['NextLocationID'] != 0) {
                                
                                  	// There is locations after this location, retrieve location information again
                                        
					$query = "SELECT Name, Description, Image, Latitude, Longitude, NextLocationID 
                                        		FROM location WHERE LocationID ='".$row['NextLocationID']."'";
					$result = mysql_query($query);
					
					$i++;
                                  	getLocations($result, $req, $i); // Call the function again
				}
				
			}
			
		}
	}
        
	// Manage the arrays into the right format
        
	$p['Locations'] = $i;
	$req['data'] = $p;
	
	$db->disconnect();
	echo json_encode($req); 

?>