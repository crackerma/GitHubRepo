<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
        $r = $_GET["p"]; //p for product barcode
        $f = $_GET["f"]; //f for Facebook ID
        $review = $_GET["review"]; //review for reviews
        $rate = $_GET["rate"]; //rate for ratings
            
	// Store product review into database
            
        if ($r != '' && $f != '' && $review != '' && $rate != '') {
        
                $query = "INSERT INTO productreview (ProductID, FacebookID, Review, Rating)
                                          Value('".$r."', '".$f."', '".$review."', '".$rate."')";
                $result = mysql_query($query);
                if($result){
                  echo("ok");
                }else{
                  echo("error");
                }
                
        }
	$db->disconnect();
	
?>