<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect();

	$r = $_GET["p"]; //p for product barcode
	
	// Create an empty array for later use
        
	$req = array( 
		"info" => '',  
		"data" => '' 
	);
	
	// Retrieve product information from database
        
	$query = "SELECT * FROM product WHERE ProductID='".$r."'";
	$result = mysql_query($query);
	
	if (mysql_num_rows($result) <= 0) {
		$req['info'] = 0; // Product Not Exist
	}
	if($result){
		while($row = mysql_fetch_array($result)){
			$req['info'] = 1; // Product Exists
			$req['data'] = array(
				"productName" => $row['Name'],
				"description" => $row['Description'],
				"image" => $row['Image'],
				"sustainabilityInformation" => $row['Sustainability'], 
				"energy" => $row['Energy'], 
				"water" => $row['Water'],
				"CO2" => $row['CO2'],
				"allergens" => '',
				"manufacturerName" => $row['ManufacturerID']
			);
		}
	}
        
	// Retrieve allergen information related to the product
	
	$allergens = "SELECT allergen.Allergen FROM allergen, productallergen, product
					WHERE product.ProductID = productallergen.productid 
					AND productallergen.allergenid = allergen.AllergenID
					AND product.ProductID =  '".$r."'";
	$resultAll = mysql_query($allergens);
	if($resultAll){
		$string = '';
		while($row = mysql_fetch_array($resultAll)){			
                  	$string[] .= $row['Allergen'];	// Put allergen information into a string
			$req['data']['allergens'] = $string;
		}
	}

	$db->disconnect();
	echo json_encode($req);
	
?>