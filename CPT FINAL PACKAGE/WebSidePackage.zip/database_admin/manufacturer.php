<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
			
	// Variables in form
        
	$pid = "";
	$mid = "";
	$manuName = "";
	$manuDes = "";
	$manuSustain = "";
	
	$query = '';
        
	// Handle submit event
			
	if(isset($_POST['submit'])) {
				
		if ( $_POST['submit'] == "Search") {
                
                  	// Search manufacturer with product barcode or manufacturer ID
                
			$query = "SELECT DISTINCT manufacturer.* FROM manufacturer, product 
						WHERE manufacturer.ManufacturerID = product.ManufacturerID 
						AND ProductID='".$_POST['pid']."' OR manufacturer.ManufacturerID='".$_POST['mid']."'";
			$result = mysql_query($query);
			
			$pid = $_POST['pid'];
                        
                        $f = 0; //Check whether manufacturer find or not
			
			if($result){
				while($row = mysql_fetch_array($result)){
					$mid = $row['ManufacturerID'];
					$manuName = $row['Name'];
					$manuDes = $row['Description'];
					$manuSustain = $row['Sustainability'];
                                        $f = 1;
				}
                                if ($f == 0) {
                                	echo '<script type="text/javascript">alert("' . "No manufacturer found" . '"); </script>';
                                } 
                  
                  	}
                        
                        $query2 = "SELECT product.ProductID FROM manufacturer, product 
						WHERE manufacturer.ManufacturerID = product.ManufacturerID 
						AND manufacturer.ManufacturerID='".$_POST['mid']."'";
			$result2 = mysql_query($query2);
                        
                        if($result2){
				while($row = mysql_fetch_array($result2)){
					$pid = $row['ProductID'];
				}
                  
                  	}
				
		} else if ( $_POST['submit'] == "Update") {
                	$new = True;
                        
                  	// Search manufacturer information against database before updating
			
			$query = "SELECT DISTINCT manufacturer.* FROM manufacturer, product 
						WHERE manufacturer.ManufacturerID = product.ManufacturerID 
						AND ProductID='".$_POST['pid']."' OR manufacturer.ManufacturerID='".$_POST['mid']."'";
			$result = mysql_query($query);
			
			if($result){
				while($row = mysql_fetch_array($result)){
					if ($row['ManufacturerID'] == $_POST['mid']) {
						$new = False;
                                                
                                                // Update existed manufacturer information
								
						$query2 = "UPDATE manufacturer SET Name = '".$_POST['mName']."', 
									Description = '".$_POST['mDes']."', Sustainability = '".$_POST['mSustain']."' 
									WHERE ManufacturerID = '".$_POST['mid']."'";
						$result2 = mysql_query($query2);
						
						if($_POST['pid'] != ''){
							$query4 = "UPDATE product SET ManufacturerID = '".$_POST['mid']."' 
										WHERE ProductID='".$_POST['pid']."'";
							$result4 = mysql_query($query4);
						}
														
						echo '<script type="text/javascript">alert("' . "Manufacturer information updated" . '"); </script>';
						
					}
				}
			}	

			if ($new == True) {
                        
                          	// Create new manufacturer information
						
				$query3 = "INSERT INTO manufacturer (Name, Description, Sustainability) 
							VALUES ('".$_POST['mName']."', '".$_POST['mDes']."', '".$_POST['mSustain']."')";
				$result3 = mysql_query($query3);
                                
                                
                                			
				if($_POST['pid'] != ''){
					$query5 = "SELECT ManufacturerID FROM manufacturer WHERE Name = '".$_POST['mName']."'";
					$result5 = mysql_query($query5);
					
					if($result5){
						while($row = mysql_fetch_array($result5)){       
                                                	
							$query4 = "UPDATE product SET ManufacturerID = '".$row['ManufacturerID']."' 
								WHERE ProductID='".$_POST['pid']."'";
                                                                
							$result4 = mysql_query($query4);
                                                        
						}
					}					
				}
                                
				echo '<script type="text/javascript">alert("' . "Manufacturer information created. The manufacturer ID of this entry is " . mysql_insert_id() . '"); </script>';								
						
			}	
				
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete manufacturer information
                
			$query = "DELETE FROM manufacturer WHERE ManufacturerID ='".$_POST['mid']."'";
			$result = mysql_query($query);
			echo '<script type="text/javascript">alert("' . "Manufacturer information deleted" . '"); </script>';
		}
				
	}
?>
		
	<form name="formProduct" method="post" action="manufacturer.php">
		<fieldset>
			<legend>Update Manufactor</legend>
			<table>
				<tr>
					<td>Product Barcode:</td>
					<td><input name="pid" type="text" id="" size="35" value=<?php echo $pid; ?>></td>
					<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
				</tr>
				<tr>
					<td>Manufacturer ID:</td>
					<td><input name="mid" type="text" id="" size="35" value=<?php echo $mid; ?>></td>
					<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
				</tr>
				<tr>
					<td>Name:</td>
					<td><textarea name="mName" rows="2" cols="28"><?php echo $manuName; ?></textarea></td>
				</tr>
				<tr>
					<td>Description:</td>
					<td><textarea name="mDes" rows="4" cols="28"><?php echo $manuDes; ?></textarea></td>
				</tr>
				<tr>
					<td>Sustainability:</td>
					<td><textarea name="mSustain" rows="4" cols="28"><?php echo $manuSustain; ?></textarea></td>							
				</tr>
				<tr>
					<td></td>
					<td  align="left">
						<input name="submit" type="submit" class="btn_grey" value="Update">
						<input name="submit" type="submit" class="btn_grey" value="Delete">
					</td>						
				</tr>
			</table>
		</fieldset>
	</form>
	
<?php		
	$db->disconnect();
 include ('footer.php');
?>