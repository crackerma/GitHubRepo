<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
			
	//Variables in form
        
	$pid = "";
	$name = "";
	$des = "";
        $img = "";
	$sustain = "";
	$energy = "";
	$water = "";
	$CO2 = "";
	
	$selection = array();
			
	$query = '';
        
	// Handle submit event
			
	if(isset($_POST['submit'])) {
				
		if ( $_POST['submit'] == "Search") {
                
                  	// Search product with product barcode
                        
                  if ($_POST['pid'] == '') {
                  
                  	echo '<script type="text/javascript">alert("' . "Please enter product barcode" . '"); </script>';
                  
                  } else {
                  
                  	$query = "SELECT * FROM product WHERE ProductID='".$_POST['pid']."'";
			$result = mysql_query($query);
                    	$f = 0; //Check whether manufacturer find or not
			if($result){
				while($row = mysql_fetch_array($result)){
					$pid = $row['ProductID'];
					$name = $row['Name'];
					$des = $row['Description'];
                                        $img = $row['Image'];
					$sustain = $row['Sustainability'];
					$energy = $row['Energy'];
					$water = $row['Water'];
					$CO2 = $row['CO2'];
                                        $f = 1;
				}
			}
                    	if ($f == 0) {
                        	echo '<script type="text/javascript">alert("' . "No product found" . '"); </script>';
                        }
                        
                  }
				
		} else if ( $_POST['submit'] == "Update") {
			$new = True;     
                        $upload = '';
                        
                  // Image upload function provided by SAE 
                        
                  if ($_FILES['myfile']['name']) {
                  	$s2 = new SaeStorage();
			$imgFile =$_FILES['myfile']['name'];
                        
                    	$s2->upload('img',$imgFile,$_FILES['myfile']['tmp_name']);
                        
                        $upload = $s2->getUrl("img",$imgFile);
                  }             
                        
			$query = "SELECT * FROM product WHERE ProductID='".$_POST['pid']."'";
			$result = mysql_query($query);
                        
                        if ($upload == '') {
                        	$upload = $_POST['image'];
                        }
			
			if($result){
				while($row = mysql_fetch_array($result)){
					if ($row['ProductID'] == $_POST['pid']) {
						$new = False;
                                                
                                          	// Update existed product
								
						$query2 = "UPDATE product SET Name = '".$_POST['pName']."', Image = '".$upload."',
									Description = '".$_POST['pDes']."', Sustainability = '".$_POST['pSustain']."', 
									Energy = '".$_POST['pEnergy']."', Water = '".$_POST['pWater']."', 
									CO2 = '".$_POST['pCO2']."' WHERE ProductID = '".$_POST['pid']."'";
						$result2 = mysql_query($query2);
						
						foreach ($_POST['allergen'] as $value) {
							
                                                  	// Update allergen information about the product
                                                        
							$query5 = "SELECT * FROM productallergen WHERE productid ='".$_POST['pid']."' AND allergenid ='".$value."'";
							$result5 = mysql_query($query5);
							$count = mysql_num_rows($result5);
							if ($count == 0) {
								
								$query3 = "INSERT INTO productallergen (allergenid, productid) 
											VALUES ('".$value."', '".$_POST['pid']."')";
								$result3 = mysql_query($query3);
							}
						}
                                                
                                          	// Check allergen information about a product, before and after submit
                                                
      						$select = $_SESSION['select'];
						
						$diff = array_diff($select, $_POST['allergen']);
						foreach ($diff as $v) {
							
							$query4 = "DELETE FROM productallergen WHERE productid ='".$_POST['pid']."' AND allergenid ='".$v."'";
							$result4 = mysql_query($query4);
						}
														
						echo '<script type="text/javascript">alert("' . "Product information updated" . '"); </script>';
						
					}
				}
			}
					
			if ($new == True) {
                        
                        	// Update existed product
                        
                                $upload = '';
                                      
                                if ($_FILES['myfile']['name']) {
                                      $s2 = new SaeStorage();
                                      $imgFile =$_FILES['myfile']['name'];
                                      
                                      $s2->upload('img',$imgFile,$_FILES['myfile']['tmp_name']);
                                      
                                      $upload = $s2->getUrl("img",$imgFile);
                                }  
						
				$query3 = "INSERT INTO product (ProductID, Name, Description, Image, Sustainability,
							Energy, Water, CO2) VALUES ('".$_POST['pid']."', '".$_POST['pName']."',
							'".$_POST['pDes']."', '".$upload."', '".$_POST['pSustain']."', 
                                                        '".$_POST['pEnergy']."', '".$_POST['pWater']."', '".$_POST['pCO2']."')";
				$result3 = mysql_query($query3);
				
                                if ($_POST['allergen'] != '') {
                                
				foreach ($_POST['allergen'] as $value) {
                                
                                	// Update allergen information about the product
                                
					$query4 = "INSERT INTO productallergen (allergenid, productid) 
								VALUES ('".$value."', '".$_POST['pid']."')";
					$result4 = mysql_query($query4);
				}					
				echo '<script type="text/javascript">alert("' . "Product information created" . '"); </script>';
				}		
			}				
				
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete product
                
			$query = "DELETE FROM product WHERE ProductID='".$_POST['pid']."'";
			$result = mysql_query($query);
                        
                	// Remove allergen information from database
               
			foreach ($_POST['allergen'] as $value) {
					$query4 = "DELETE FROM productallergen WHERE productid ='".$_POST['pid']."' AND allergenid ='".$value."'";
					$result4 = mysql_query($query4);
				}	
			echo '<script type="text/javascript">alert("' . "Product deleted" . '"); </script>';
		}
				
	}
?>
		
	<form enctype="multipart/form-data" name="formProduct" method="post" action="product.php">
		<fieldset>
			<legend>Update Product</legend>
			<table>
				<tr>
					<td>Barcode:</td>
					<td><input name="pid" type="text" id="" size="35" value=<?php echo $pid; ?>></td>
					<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
				</tr>
				<tr>
					<td>Name:</td>
					<td><textarea name="pName" rows="2" cols="28"><?php echo $name; ?></textarea></td>
				</tr>
				<tr>
					<td>Description</td>
					<td><textarea name="pDes" rows="4" cols="28"><?php echo $des; ?></textarea></td>
				</tr>
				<tr>
					<td>Image:
                                        	<input type="hidden" name="image" id="image_location" value="<?php echo $img; ?>" />
                                        </td>
					<td><img src="<?php echo $img; ?>">
                                        
                                          <br />
                                          <input name='myfile' type='file'/>
                                        
                                        </td>
				</tr>
				<tr>
					<td>Sustainability:</td>
					<td><textarea name="pSustain" rows="4" cols="28"><?php echo $sustain; ?></textarea></td>							
				</tr>
				<tr>
					<td>Energy Consumption:</td>
					<td><input name="pEnergy" type="text" id="" size="35" value=<?php echo $energy; ?>></td>
				</tr>
				<tr>
		
					<td>Water Consumption:</td>
					<td><input name="pWater" type="text" id="" size="35" value=<?php echo $water; ?>></td>
				</tr>
				<tr>
					<td>CO2:</td>
					<td><input name="pCO2" type="text" id="" size="35" value=<?php echo $CO2; ?>></td>
				</tr>
				<tr>
					<td>Allergen:</td>
					<td>
					<?php
						$query = "SELECT * FROM allergen";
						$result = mysql_query($query);
						if ($result) {
							while($row = mysql_fetch_array($result)){
					?>
						<input type="checkbox" name="allergen[]" value= "<?php echo $row['AllergenID']; ?>" 
						<?php
								$query2 = "SELECT allergen.AllergenID, productallergen.productid FROM allergen, 
											productallergen WHERE allergen.AllergenID = productallergen.allergenid
											AND productallergen.productid = '".$pid."'";
								$result2 = mysql_query($query2);
								
								if ($result2) {
									while($row2 = mysql_fetch_array($result2)){
										if ($row2['AllergenID'] == $row['AllergenID']) {
											echo "checked";
											array_push($selection, $row['AllergenID']);
                                                                                        $_SESSION['select'] = $selection;
										}
									}
								}
								
								
							
						?> > 
					<?php echo $row['Allergen']; ?>
					<?php
							}
						}
					?>
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<input name="submit" type="submit" class="btn_grey" value="Update">
						<input name="submit" type="submit" class="btn_grey" value="Delete">
					</td>						
				</tr>				
			</table>
		</fieldset>
	</form>
	
<?php
	
	$db->disconnect();
        
 include ('footer.php');
?>