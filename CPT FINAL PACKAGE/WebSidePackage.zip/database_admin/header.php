<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/2002/REC-xhtml1-20020801/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>CPT Database Administration</title>

<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div id="top">
    <div id="head_container">
	
        <ul>			
		<?php
                
			// If user login, display logout on the tab. Otherwise, display login.
                
			if(isset($_SESSION['username']) && isset($_SESSION['password'])){
				print ('<li><a href="logout.php">Logout</a></li>');
			} else {
				print ('<li><a href="index.php">Home</a></li>');
			}            
		?>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
		
        <a href="index.php" id="logo"><img src="image/58310_4625900086266_1132793981_n.jpg" width="272" height="111" alt="logo" /></a>
    
    </div>
</div>