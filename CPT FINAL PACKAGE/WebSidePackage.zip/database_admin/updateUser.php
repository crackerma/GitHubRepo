<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	} else if ($_SESSION['auth'] >= 2) {
		header("Location: index.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");	
	
	// Handle submit event
        
	if(isset($_POST['submit'])) {
		if ( $_POST['submit'] == "Update") {
                
                  	// Update user account
                
			$query = "UPDATE user SET Username = '".$_POST['uName']."',
						Password = '".$_POST['pass']."', Name = '".$_POST['name']."',
						Description = \"".$_POST['des']."\", Email = '".$_POST['mail']."', 
						Permissions = '".$_POST['permit']."' WHERE UserID = '".$_POST['uid']."'";
			$result = mysql_query($query);
			
			echo '<script type="text/javascript">alert("' . "Account information updated" . '"); </script>';
                        
                        
			
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete user account
                
			$query = "DELETE FROM user WHERE UserID = '".$_POST['uid']."'";
			$result = mysql_query($query);
                        
			echo '<script type="text/javascript">alert("' . "Account deleted" . '"); </script>';
                        
                        
		}
	} else {
        
        // Display account details
	
	$query = "SELECT * FROM user WHERE UserID = '".$_GET['user']."'";
	$result = mysql_query($query);
	
	if($result){
		while($row = mysql_fetch_array($result)){
?>
<form name="formUser" method="post" action="updateUser.php">
	<fieldset>
		<legend>Update Account</legend>
		<table>
			<tr>
				<td>UserID:</td>
				<td><input name="uid" type="text" id="" size="35" value=<?php echo $row['UserID']; ?>></td>					
			</tr>
			<tr>
				<td>Username:</td>
				<td><input name="uName" type="text" id="" size="35" value=<?php echo $row['Username']; ?>></td>					
			</tr>
			<tr>
				<td>Password:</td>
				<td><input name="pass" type="text" id="" size="35" value=<?php echo $row['Password']; ?>></td>
			</tr>
			<tr>
				<td>Name:</td>
				<td><textarea name="name" rows="2" cols="28"><?php echo $row['Name']; ?></textarea></td>
			</tr>
			<tr>
				<td>Description:</td>
				<td><textarea name="des" rows="4" cols="28"><?php echo $row['Description']; ?></textarea></td>							
			</tr>
			<tr>
				<td>Email:</td>
				<td><textarea name="mail" rows="2" cols="28"><?php echo $row['Email']; ?></textarea></td>							
			</tr>
			<tr>
				<td>Type:</td>
				<td>
				<?php 
					if ($_SESSION['auth'] == 1) {
				?>
						<input type="radio" name="permit" value="2" <?php if($row['Permissions'] == 2){print "checked";}?>>Retailer
				<?php
					} else {
				?>
						<input type="radio" name="permit" value="1" <?php if($row['Permissions'] == 1){print "checked";}?>>Administrator
						<input type="radio" name="permit" value="2" <?php if($row['Permissions'] == 2){print "checked";}?>>Retailer
				<?php
					}
				?>
				</td>							
			</tr>
			<tr>
				<td></td>
				<td  align="left">
					<input name="submit" type="submit" class="btn_grey" value="Update">
					<input name="submit" type="submit" class="btn_grey" value="Delete">
				</td>	
			</tr>
		</table>
	</fieldset>
</form>
<?php
		}
	}
	}
	$db->disconnect();
 include ('footer.php');
?>