<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(isset($_SESSION['username']) && isset($_SESSION['password'])){
		header("Location: index.php");
	}
	
	include ('header.php');
?>

<div class="content"> 
    <form name="form1" method="post" action="validate.php">
        <table>	
			<tr>
				<td>Username: </td>
				<td>
                <input name="name" type="text" class="logininput" id="name" size="30"></td>			 
			</tr>
            <tr>
				<td>Password: </td>
				<td><input name="pwd" type="password" class="logininput" id="pwd" size="30"></td>
			</tr>
			<tr>
				<td style="color:red;" class"error" colspan=2>
				<?php
				if (isset($_SESSION['login_error'])) {
					echo $_SESSION['login_error'];
				};
				?>
				</td>
			</tr>
			<tr>
                <td colspan="2" align="center"><input name="Submit" type="submit" class="btn_grey" value="LOGIN" onClick="">
				<input name="Submit3" type="reset" class="btn_grey" value="RESET">
				<input name="Submit2" type="button" class="btn_grey" value="CLOSE" onClick="window.close();"></td>
			</tr>
        </table> 
		
	</form>	
</div>

<?php
	include ('footer.php');
?>

