<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
?>
		

<?php
	include ('footer.php');
?>