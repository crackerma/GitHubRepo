<?php

// This function is powered by SAE server

$s2 = new SaeStorage();
$name =$_FILES['myfile']['name'];

echo $s2->upload('img',$name,$_FILES['myfile']['tmp_name']); //upload the image file to server
// echo $s2->getUrl("test",$name); //output the storage url
echo '<br/>';
echo $s2->errmsg(); //echo any error messages 
?>