<?php
	class MySQLDatabase{
		var $link;
	
		function connect(){
                
                  // Connect setting to the database, should be changed according to the MYSQL database setting
                
		   $this->link = mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT, SAE_MYSQL_USER, SAE_MYSQL_PASS);
		   if(!$this->link){
			  die('Not connected : ' . mysql_error());
		   }
		   $db = mysql_select_db(SAE_MYSQL_DB, $this->link);
		   if(!$db){
			  die ('Cannot use : ' . mysql_error());
		   }
		   return $this->link;
		}
			
		function disconnect(){
		   mysql_close($this->link);
		}
	}
?>