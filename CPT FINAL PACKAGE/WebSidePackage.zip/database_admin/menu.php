<div class="rightMenu">
	<ul>
		<li><a href="product.php">Manage Product</a></li>
		<li><a href="allergen.php">Manage Allergen List</a></li>
		<li><a href="manufacturer.php">Manage Manufacturer</a></li>
		<li><a href="location.php">Manage Location</a></li>
		<li><a href="user.php">Manage Accounts</a></li>
		<li><a href="flag.php">Flagged Content Administration</a></li>
		
    </ul>

</div>