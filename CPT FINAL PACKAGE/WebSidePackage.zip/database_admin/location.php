<?php
	session_start();
        
        // If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
		
		
	// Variables created for later use
        
	$count = 0;
	$next;
	$arr;
	$query = '';
		
	// Handle submit event
                
	if(isset($_POST['submit'])) {
	
		if ( $_POST['submit'] == "New") {
                
                	$upload = '';
                              
                        // Image upload function provided by SAE 
                              
                        if ($_FILES['myfile']['name']) {
                              $s2 = new SaeStorage();
                              $imgFile =$_FILES['myfile']['name'];
                              
                              $s2->upload('img',$imgFile,$_FILES['myfile']['tmp_name']);
                              
                              $upload = $s2->getUrl("img",$imgFile);
                        }  
                
                  	// Create new location entry
                
			$new = "INSERT INTO location(`LocationID`, `ProductId`, `Name`, `Description`, `Image`, `Latitude`,
						`Longitude`, `NextLocationID`) VALUES (NULL , '".$_POST['pid']."', '".$_POST['lName']."', 
						\"".$_POST['lDes']."\",	'".$upload."' , '".$_POST['lati']."', '".$_POST['long']."', '".$_POST['next']."')";
			$resultNew = mysql_query($new);
                        
                        if ($resultNew) {
                        	echo '<script type="text/javascript">alert("' . "New location created. The location ID of this entry is " . mysql_insert_id() . '"); </script>';
                        } else {
                        	echo '<script type="text/javascript">alert("' . mysql_error() . '"); </script>';
                        }
                        
                        
		} else {
                
                // Retrieve location information by product barcode or location ID
	
                $query = "SELECT * FROM location WHERE location.ProductID='".$_POST['pid']."'
                		OR location.LocationID='".$_POST['lid']."'";
		$result = mysql_query($query);
		
						
		if ( $_POST['submit'] == "Search") {	
                
                if (mysql_num_rows($result) == 0) {
                    echo '<script type="text/javascript">alert("' . "No location found" . '"); </script>';
                  }
				if($result){
					while($row = mysql_fetch_array($result)){
                                        
                                          	// Put first location in the array

						$arr[$count] = array(
							"pid" => $row['ProductId'],
							"lid" => $row['LocationID'],
							"lName" => $row['Name'],
							"lDes" => $row['Description'],
							"Image" => $row['Image'], 
							"lati" => $row['Latitude'], 
							"long" => $row['Longitude'],
							"next" => $row['NextLocationID']
						);				
						
						$count++;
						$next = $row['NextLocationID'];			
						
						while ($next != 0) {
                                                
                                                  	// Put the sequential location into the array until the last one
		
							$query = "SELECT LocationID, Name, Description, Image, Latitude, Longitude, 
										NextLocationID FROM location WHERE LocationID ='".$next."'";
							$result = mysql_query($query);
							
							if($result){
								while($row = mysql_fetch_array($result)){
									
									$arr[$count] = array(	
										"lid" => $row['LocationID'],
										"lName" => $row['Name'],
										"lDes" => $row['Description'],
										"Image" => $row['Image'], 
										"lati" => $row['Latitude'], 
										"long" => $row['Longitude'],
										"next" => $row['NextLocationID']
									);
									
									$count++;
									$next = $row['NextLocationID'];
								
								}
							}
						}
						
					}
					
				}
                                
                  
			
				
		} else if ( $_POST['submit'] == "Update") {
                
                      	$upload = '';
                              
                        // Image upload function provided by SAE 
                              
                        if ($_FILES['myfile']['name']) {
                              $s2 = new SaeStorage();
                              $imgFile =$_FILES['myfile']['name'];
                              
                              $s2->upload('img',$imgFile,$_FILES['myfile']['tmp_name']);
                              
                              $upload = $s2->getUrl("img",$imgFile);
                        }    
                        
                        if ($upload == '') {
                        	$upload = $_POST['image'];
                        }
						
                  	// Update location information
                                                
			$query = "SELECT * FROM location WHERE LocationID = '".$_POST['lid']."'";
			$result = mysql_query($query);
			
			if($result){
				while($row = mysql_fetch_array($result)){
					if ($row['LocationID'] == $_POST['lid']) {
														
						$query2 = "UPDATE location SET ProductId = '".$_POST['pid']."', Image = '".$upload."',
									Name = '".$_POST['lName']."', Description = \"".$_POST['lDes']."\",
									Latitude = '".$_POST['lati']."', Longitude = '".$_POST['long']."', 
									NextLocationID = '".$_POST['next']."' WHERE LocationID = '".$_POST['lid']."'";
						$result2 = mysql_query($query2);
		
						$count = 0;
						echo '<script type="text/javascript">alert("' . "Location information updated" . '"); </script>';
						
					}
				}
			}	

				
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete location information
                
			$query = "DELETE FROM location WHERE LocationID = '".$_POST['lid']."'";
			$result = mysql_query($query);
			echo '<script type="text/javascript">alert("' . "Location deleted" . '"); </script>';
		} 
		}
		
	}
	
	if ($count > 0) {
				
?>
<?php

        // Print out all the locations

	for ($a = 0; $a < $count; $a++) {

?>
        <div class="left">
	<form enctype="multipart/form-data" name="formLocation" method="post" action="location.php">
		<fieldset>
			<legend>Update Location</legend>
			<table>
				<tr>
					<td>Product Barcode:</td>
					<td><input name="pid" type="text" id="" size="35" value=<?php echo $arr[0]['pid']; ?>></td>
					
				</tr>

				<tr>
					<td>Location ID:</td>
					<td><input name="lid" type="text" id="" size="35" value=<?php echo $arr[$a]['lid']; ?>></td>
					
				</tr>
				<tr>
					<td>Name:</td>
					<td><textarea name="lName" rows="2" cols="28"><?php echo $arr[$a]['lName']; ?></textarea></td>
				</tr>
				<tr>
					<td>Description:</td>
					<td><textarea name="lDes" rows="4" cols="28"><?php echo $arr[$a]['lDes']; ?></textarea></td>
				</tr>
                                <tr>
					<td>Image:
                                        	<input type="hidden" name="image" id="image_location" value="<?php echo $arr[$a]['Image']; ?>" />
                                        </td>
					<td><img src="<?php echo $arr[$a]['Image']; ?>">
                                        
                                          <br />
                                          <input name='myfile' type='file'/>
                                        
                                        </td>
				</tr>
				<tr>
					<td>Latitude:</td>
					<td><textarea name="lati" rows="4" cols="28"><?php echo $arr[$a]['lati']; ?></textarea></td>							
				</tr>
				<tr>
					<td>Longitude:</td>
					<td><textarea name="long" rows="4" cols="28"><?php echo $arr[$a]['long']; ?></textarea></td>							
				</tr>
				<tr>
					<td>Next Location:</td>
					<td><textarea name="next" rows="4" cols="28"><?php echo $arr[$a]['next']; ?></textarea></td>							
				</tr>
				<tr>
					<td></td>
					<td  align="left">
						<input name="submit" type="submit" class="btn_grey" value="Update">
						<input name="submit" type="submit" class="btn_grey" value="Delete">
					</td>	
				</tr>
									</table>
		</fieldset>
	</form>
	</div>
<?php		
		}

?>
	

<?php
	} else {
        
        
        
?>

	<form name="formLocation" method="post" action="location.php">
		<fieldset>
			<legend>Search Location</legend>
			<table>
				<tr>
					<td>Product Barcode:</td>
					<td><input name="pid" type="text" id="" size="35"></td>
					<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
				</tr>
				<tr>
					<td>Location ID:</td>
					<td><input name="lid" type="text" id="" size="35"></td>
					<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
				</tr>
			</table>
		</fieldset>
	</form>
	
	<form enctype="multipart/form-data" name="formLocation" method="post" action="location.php">
		<fieldset>
			<legend>Create Location</legend>
			<table>
				<tr>
					<td>Product Barcode:</td>
					<td><input name="pid" type="text" id="" size="35"></td>
					
				</tr>
				<tr>
					<td>Name:</td>
					<td><textarea name="lName" rows="2" cols="28"></textarea></td>
				</tr>
				<tr>
					<td>Description:</td>
					<td><textarea name="lDes" rows="4" cols="28"></textarea></td>
				</tr>
                                <tr>
					<td>Image:</td>
					<td>
                                          <input name='myfile' type='file'/>
                                        
                                        </td>
				</tr>
				<tr>
					<td>Latitude:</td>
					<td><textarea name="lati" rows="4" cols="28"></textarea></td>							
				</tr>
				<tr>
					<td>Longitude:</td>
					<td><textarea name="long" rows="4" cols="28"></textarea></td>							
				</tr>
				<tr>
					<td>Next Location:</td>
					<td><textarea name="next" rows="4" cols="28"></textarea></td>							
				</tr>
				<tr>
					<td></td>
					<td  align="left">
						<input name="submit" type="submit" class="btn_grey" value="New">
					</td>	
				</tr>
			</table>
		</fieldset>
	</form>
	
<?php
	} 
                
	$db->disconnect();
 include ('footer.php');
?>
