<div id="footer">
  Copyright &copy; 2012 Group Unknown
</div>


</body>
</html>