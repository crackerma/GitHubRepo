<?php
	session_start();
        
        // If not login, then redirct to login page
        
 	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
	
	if($_POST['name'] && $_POST['pwd']){
		$name = mysql_real_escape_string($_POST['name']);
		$pass = mysql_real_escape_string($_POST['pwd']);
		
		$query = "SELECT * FROM user";
		$result = mysql_query($query);
		if($result){			
			while($row = mysql_fetch_array($result)){
				
                          	// Check login details against database
                                
				if ($row['Username'] == $name && $row['Password'] == $pass) {		
					
					$_SESSION['username'] = $name;
					$_SESSION['password'] = $pass;
					$_SESSION['auth'] = $row['Permissions'];
					header("Location: index.php");
					
				} else {
				
					$message = "Login Failed: Incorrect username or password";
					$_SESSION['login_error'] = $message;
					header( 'Location: login.php' ) ;
					
				}
			}
			$db->disconnect();
		}
	} else {
        	$message = "Username or Password is not entered.";
		$_SESSION['login_error'] = $message;
		header( 'Location: login.php' ) ;
        }
	
?>
	