<?php
	session_start();
        
        // If not login, then redirct to login page
        
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	} else if ($_SESSION['auth'] >= 2) {
		header("Location: index.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
	
	$count = 0;
        
	// Handle submit event
	
	if(isset($_POST['submit'])) {
		if ( $_POST['submit'] == "Create") {
                
                  	// Create new user account, either administrator or retailer
                
			$query = "INSERT INTO user(`UserID`, `Username`, `Password`, `Name`, `Description`, `Email`,
						`Permissions`) VALUES (NULL , '".$_POST['uName']."', '".$_POST['pass']."', '".$_POST['name']."', 
						\"".$_POST['des']."\", '".$_POST['mail']."', '".$_POST['permit']."')";
			$result = mysql_query($query);
			
                        echo '<script type="text/javascript">alert("' . "Account created" . '"); </script>';
		}		
	}
?>

		<fieldset>
			<legend>Manage Account</legend>
			<table>
				<tr>
					<th>UserID</th>
					<th>Username</th>
					<th>Name</th>
					<th>Description</th>
					<th>Email</th>
					<th>Type</th>
				</tr>
				
				<?php
                                
					// Display accounts that you have privilege to manage
                                
					$query = "SELECT * FROM user WHERE Permissions > '".$_SESSION['auth']."'";
					$result = mysql_query($query);

					$count= mysql_num_rows($result);
					
					if ($count > 0) {
						if($result){
							while($row = mysql_fetch_array($result)){
								?>
								<tr>
								<td name="uid"><?php echo $row['UserID']; ?></td>
								<td><?php echo $row['Username']; ?></td>
								<td><?php echo $row['Name']; ?></td>
								<td><?php echo $row['Description']; ?></td>
								<td><?php echo $row['Email']; ?></td>
								<td><?php 
									if ($row['Permissions'] == 1) {
										echo "Administrator";
									} else {
										echo "Retailer";
									}
									?></td>
								<td><a href="updateUser.php?user=<?php echo "{$row['UserID']}"; ?>">Update</a></td>
								</tr>
								<?php
							}
						}
					}
					
				?>
						
			</table>
		</fieldset>

<form name="formAccount" method="post" action="user.php">
		<fieldset>
			<legend>Create Account</legend>
			<table>
				<tr>
					<td>Username:</td>
					<td><input name="uName" type="text" id="" size="35"></td>					
				</tr>
				<tr>
					<td>Password:</td>
					<td><input name="pass" type="text" id="" size="35"></td>
				</tr>
				<tr>
					<td>Name:</td>
					<td><textarea name="name" rows="2" cols="28"></textarea></td>
				</tr>
				<tr>
					<td>Description:</td>
					<td><textarea name="des" rows="4" cols="28"></textarea></td>							
				</tr>
				<tr>
					<td>Email:</td>
					<td><textarea name="mail" rows="2" cols="28"></textarea></td>							
				</tr>
				<tr>
					<td>Type:</td>
					<td><input type="radio" name="permit" value="1">Administrator
						<input type="radio" name="permit" value="2">Retailer</td>							
				</tr>
				<tr>
					<td></td>
					<td  align="left">
						<input name="submit" type="submit" class="btn_grey" value="Create">
					</td>	
				</tr>
			</table>
		</fieldset>
	</form>
<?php		
	$db->disconnect();
 include ('footer.php');
?>