<?php
	session_start();
        
	// If not login, then redirct to login page
	
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
	
	// Handle submit event
        
	if(isset($_POST['submit'])) {
		if ( $_POST['submit'] == "Add New") {
                	
                  	// Add new allergen to database
                        
			$query = "INSERT INTO allergen (AllergenID, Allergen) VALUES (NULL, '".$_POST['allergenNew']."')";
			$result = mysql_query($query);
                        
                        echo '<script type="text/javascript">alert("' . "Allergen added" . '"); </script>';
                        
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete product-allergen entries where product has this allergen
                
			$query2 = "SELECT AllergenID FROM allergen WHERE Allergen ='".$_POST['allergen']."'";
			$result2 = mysql_query($query2);
			if($result2){
				while($row = mysql_fetch_array($result2)){
					$query3 = "DELETE FROM productallergen WHERE allergenid='".$row['AllergenID']."'";
					$result3 = mysql_query($query3);
				}
			}
                        
                        // Delete existed allergen from database
                        
			$query = "DELETE FROM allergen WHERE Allergen='".$_POST['allergen']."'";
			$result = mysql_query($query);		
                        
                        echo '<script type="text/javascript">alert("' . "Allergen deleted" . '"); </script>';
		}
	}
?>
	<form name="formAllergen" method="post" action="allergen.php">
		<fieldset>
		<legend>Allergen List</legend>
			<table>
			<tr>
				<td colspan=2>Manage Allergen</td>
			</tr>
			<?php
                        
			// Output all existed allergens with a delete botton
                        
			$query = "SELECT * FROM allergen";
			$result = mysql_query($query);
			if($result){
				while($row = mysql_fetch_array($result)){
			?>
			<tr>
				<td><input name="allergen" type="text" value=<?php echo $row['Allergen']; ?>></td>
				<td><input name="submit" type="submit" class="btn_grey" value="Delete"></td>
			</tr>
			<?php
				}
			}
			?>			
			<tr>
				<td><input name="allergenNew" type="text"></td>
				<td><input name="submit" type="submit" class="btn_grey" value="Add New"></td>
			</tr>
			</table>
		</fieldset>	
	</form>

<?php
	$db->disconnect();
	include ('footer.php');
?>