<?php
	session_start();
        
        // If not login, then redirct to login page
        
	if(!isset($_SESSION['username']) && !isset($_SESSION['password'])){
		header("Location: login.php");
	}
	
	include ('header.php');
	include ('menu.php');
	
	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
	
	$count = 0;
        
	// Handle submit event
	
	if(isset($_POST['submit'])) {
		if ( $_POST['submit'] == "Search") {
                
                                    

			if ($_POST['pid'] != NULL) {
                        
                          	// Search flagged record by product barcode
                        
				$query = "SELECT flagged.FlaggedID, Name, flagged.Message, `Managed By` FROM product, flagged
							WHERE flagged.ProductID = product.ProductID AND flagged.ProductID = '".$_POST['pid']."'";
				$result = mysql_query($query);
				$count++;
                          if (mysql_num_rows($result) == 0) {
                          	echo '<script type="text/javascript">alert("' . "No flagged item found" . '"); </script>';
                          }
                                
			} else if ($_POST['mid'] != NULL) {
                        
                        	// Search flagged record by manufacturer ID
                        
				$query = "SELECT flagged.FlaggedID, Name, flagged.Message, `Managed By` FROM manufacturer, flagged
							WHERE flagged.ManufacturerID = manufacturer.ManufacturerID AND flagged.ManufacturerID = '".$_POST['mid']."'";
				$result = mysql_query($query);
				$count++;
                                if (mysql_num_rows($result) == 0) {
                          	echo '<script type="text/javascript">alert("' . "No flagged item found" . '"); </script>';
                          }
                                
			} else {
                        echo '<script type="text/javascript">alert("' . "Please fill in search field!" . '"); </script>';
                        }
                
			
			
		} else if ( $_POST['submit'] == "Update") {
                
                  	// Update flagged record
                
			$query = "UPDATE flagged SET `Managed By` = '".$_POST['adMsg']."' WHERE FlaggedID = '".$_POST['fid']."'";
			$result = mysql_query($query);
                  	echo '<script type="text/javascript">alert("' . "Record Updated" . '"); </script>';
                        
		} else if ( $_POST['submit'] == "Delete") {
                
                  	// Delete flagged record
                
			$query = "DELETE FROM flagged WHERE FlaggedID = '".$_POST['fid']."'";
			$result = mysql_query($query);
			echo '<script type="text/javascript">alert("' . "Record Deleted" . '"); </script>';
                        
		}
	}
?>
<form name="formSearch" method="post" action="flag.php">
	<fieldset>
		<legend>Search Flagged Items</legend>
		<table>
			<tr>
				<td>Product Barcode:</td>
				<td><input name="pid" type="text" id="" size="35"></td>
				<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
			</tr>
			<tr>
				<td>Manufacturer ID:</td>
				<td><input name="mid" type="text" id="" size="35"></td>
				<td><input name="submit" type="submit" class="btn_grey" value="Search"></td>
			</tr>
		</table>
	</fieldset>
</form>
<?php

	// Print out the flagged records

	if ($count > 0) {
		if ($result) {
			while($row = mysql_fetch_array($result)){
?>
	<form name="formProduct" method="post" action="flag.php">
		<fieldset>
			<legend>Flagged Items</legend>
			<table>
				<tr>
					<td>Flag ID:</td>
					<td><input name="fid" type="text" id="" size="35" value=<?php echo $row['FlaggedID']; ?>></td>					
				</tr>
				<tr>
					<td>Item Name:</td>
					<td><input name="pName" type="text" id="" size="35" value=<?php echo $row['Name']; ?>></td>	
				</tr>
				<tr>
					<td>Message:</td>
					<td><textarea name="msg" rows="2" cols="28"><?php echo $row['Message']; ?></textarea></td>
				</tr>
				<tr>
					<td>Administrator Messge:</td>
					<td><textarea name="adMsg" rows="4" cols="28"><?php echo $row['Managed By']; ?></textarea></td>
				</tr>				
				<tr>
					<td></td>
					<td  align="left">
						<input name="submit" type="submit" class="btn_grey" value="Update">
						<input name="submit" type="submit" class="btn_grey" value="Delete">
					</td>	
				</tr>
			</table>
		</fieldset>
	</form>
<?php				
			}
		}
	}

	$db->disconnect();
 include ('footer.php');
?>