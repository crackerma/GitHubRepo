<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");

	$r = $_GET["p"]; //p for product barcode
	$m = $_GET["m"]; //uid for flagged user
	$msg = $_GET["msg"]; //msg for message
	
	// write the received message into database
        
        if ($r != '' && $m != '' && $msg != '') {
        
          $query = "INSERT INTO flagged VALUES (NULL, '".$r."', '".$m."', '".$msg."', '')";
          $result = mysql_query($query);
          
          if ($result) {
                  echo "Success";
          }
        }
        
	$db->disconnect();
	
?>