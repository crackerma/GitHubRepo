<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");
	
	$r = $_GET["p"]; //p for product barcode
	
	// Retrieve manufacturer information of specific product
        
	$query = "SELECT manufacturer.* FROM manufacturer, product 
				WHERE manufacturer.ManufacturerID = product.ManufacturerID 
				AND ProductID='".$r."'";
	$result = mysql_query($query);
	
	if (mysql_num_rows($result) <= 0) {
		$req['info'] = 0; // Product Not Exist
	}
	if($result){
		while($row = mysql_fetch_array($result)){
			$req['info'] = 1; // Product Exists
			$req['data'] = array(
				"manufacturerName" => $row['Name'],
				"description" => $row['Description'],
				"sustainabilityInformation" => $row['Sustainability']
			);
		}
	}
	
	$db->disconnect();
	echo json_encode($req);
	
?>