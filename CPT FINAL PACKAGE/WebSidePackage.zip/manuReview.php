<?php

	include('connectMySQL.php');
	$db = new MySQLDatabase(); 
	$db->connect("root", "", "productitems");

	$mid = $_GET["mid"]; //mid for Manufacturer ID
	
	// Create an empty array for later use
        
	$req = array( 
		"info" => '',  
		"data" => '' 
	);
        
	// Retrieve manufacturer reviews from database
	
	$query = "SELECT DISTINCT manufacturer.Name, manufacturerreview.* FROM manufacturerreview, manufacturer
				WHERE manufacturer.ManufacturerID = manufacturerreview.ManufacturerID 
				AND manufacturer.ManufacturerID='".$mid."'";
	$result = mysql_query($query);
	
	if (mysql_num_rows($result) <= 0) {
		$req['info'] = 0; // Product Not Exist
	}
	if($result){		
		$list = '';
		while($row = mysql_fetch_array($result)){
			$req['info'] = 1; // Product Exists
			$list[] = array(
				"manufacturerName" => $row['Name'],
				"facebookID" => $row['FacebookID'], 
				"reviews" => $row['Review'],
				"ratings" => $row['Rating']
			);
		}
		$req['data'] = $list;
	}
	
	$db->disconnect();
	echo json_encode($req);
	
?>