<?php
echo '<strong>Welcome to SAE!</strong>';