<?php
	$mysql = new SaeMysql();
	$sql = "SELECT * FROM product";
	$data_array = $mysql->getData($sql);
	if($mysql->errno()!=0) die("Mysql error".$mysql->error());
	foreach($data_array as $line):
		echo $data_array['Name'];
	endforeach;
?>